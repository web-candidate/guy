<?php get_header(); ?> <!-- importation du header -->

<!-- ici on placera la loop wordpress -->

<!-- ici on place la sidebar -->
<?php get_sidebar(); ?>

<!-- ici on place le footer -->
<?php get_footer(); ?>