<div id="footer">
<p>
Copyright � <?php print(date(Y)); ?> <?php bloginfo('name'); ?>
<br />
Blog propuls� par <a href="http://wordpress.org/">WordPress</a>
<br />
<a href="feed:<?php bloginfo('rss2_url'); ?>">Articles (RSS)</a> et <a href="feed:<?php bloginfo('comments_rss2_url'); ?>">Commentaires (RSS)</a>.
<?php echo get_num_queries(); ?> requ�tes. <?php timer_stop(1); ?> secondes.
</p>
</div>
</div>
</body>
</html>